import React from 'react';
import ImageLoader from './ImageLoader'
import LetterBox from './LetterBox'
import XmlParser from './XmlParser'
class App extends React.Component {
    render(){

        return (
                
                <div> <h1><ImageLoader/></h1>

                <h2><LetterBox/></h2></div>
        );
    }
}
 
export default App;