import React from 'react';

class ImageLoader extends React.Component {
   
 
    

    render(){
    var imageUrl = './image1.png'
    var imageStyle = {
            color : 'black',

            width : 1920,
            height : 1080,
            
            maxWidth : '100%',
            maxHeight : '100%',
            backgroundSize: 'cover',
            backgroundRepeat: 'no-repeat',
            
            backgroundImage: 'url('+imageUrl+')',
            WebkitTransition: 'all', // note the capital 'W' here
            msTransition: 'all' // 'ms' is the only lowercase vendor prefix
        };
        return (
            <div style = {imageStyle}></div>
        );
    }
}



export default ImageLoader;