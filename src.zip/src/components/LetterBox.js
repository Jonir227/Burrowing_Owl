import React from 'react';


class LetterBox extends React.Component {
    render(){
        var boxStyle = {
           width:'100%',
           height:200,
           background : 'black',
           padding : 10,
           borderWidth : 10,
           borderColor : 'white',
           borderStyle : 'solid'
        }
        var letterStyle = {
            fontFamily : "맑은 고딕",
           fontSize : 50,
           color : 'white'
        }
        return (
           <div style = {boxStyle}>
            <div style = {letterStyle}>흥부야 놀자</div>
            </div>
        );
    }
}

export default LetterBox;